=====
Twitter Past Crawler
=====
A crawler that accumulates past tweets.
--------
Although twitter offers an official to accumulate past tweets, the API as of now is extremely limiting in the access it provides to past tweets. This crawler attempts to provide users the ability to collect past tweets beyond those limitations, by emulating the infinte scroll on browsers.
